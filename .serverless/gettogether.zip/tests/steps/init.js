module.exports.init = () => {
  process.env.AWS_REGION = "eu-west-1";
};
